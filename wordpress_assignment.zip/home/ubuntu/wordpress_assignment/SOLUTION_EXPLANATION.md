# WordPress Developer Assignment Solution

This solution provides the complete code for a custom WordPress theme template designed to meet all the requirements of the mobile homepage recreation assignment, focusing on dynamic content management via Advanced Custom Fields (ACF).

## 1. Theme Structure and Files

The solution is provided as a minimal, self-contained theme structure.

| File Name | Purpose | Assignment Requirement Met |
| :--- | :--- | :--- |
| `page-homepage.php` | The custom page template that renders the mobile homepage layout. It uses standard WordPress and ACF functions to fetch all content dynamically. | Replicate mobile layout, Dynamic Content Handling, No hardcoded text/images. |
| `style.css` | The mobile-first CSS file for styling the layout. It ensures the design is responsive and clean. | Design Accuracy (Mobile), Clean class names. |
| `functions.php` | Contains necessary WordPress functions (like `get_header`, `get_footer`, and `wp_enqueue_scripts`) and **mockup functions** for ACF and WooCommerce to demonstrate the code's logic without a full WordPress/WooCommerce installation. | Code Structure & Cleanliness. |
| `acf_structure.md` | Documentation detailing the required ACF Field Groups and fields for the CMS setup. | CMS Usability, Backend Structure. |

## 2. Dynamic Content and CMS Usability (ACF Implementation)

The core requirement is to make all content easily editable by a non-developer. This is achieved by defining a single ACF Field Group, "Mobile Homepage Content," which is assigned to a custom page template named "Mobile Homepage Template" (`page-homepage.php`).

### ACF Field Group Summary

| Section | ACF Field Type | Editability |
| :--- | :--- | :--- |
| **Announcement Bar** | Text | Business user can easily update the text. |
| **Hero Banner** | Image, Text, URL | Business user can change the image, heading, subheading, button text, and link. |
| **Brand Logos** | Repeater (Image sub-field) | Business user can add, remove, or reorder brand logos dynamically. |
| **New Arrivals** | Taxonomy (Product Category) | Business user can select a different product category/collection to feature. |

### Code Implementation Details

1.  **`page-homepage.php`** is the main template. It checks for the existence of ACF functions (`if ( function_exists( 'get_field' ) )`) before attempting to retrieve data, ensuring robustness.
2.  **Announcement Bar**: Uses `get_field('announcement_bar_text')`.
3.  **Hero Banner**: Uses individual fields for image ID (`wp_get_attachment_image`), heading, subheading, button text, and button link (`esc_url`).
4.  **Brand Logos**: Uses the `have_rows('brand_logos')` and `the_row()` loop structure, which is the standard, clean way to handle repeatable content in ACF.
5.  **New Arrivals**:
    *   The heading is a simple text field.
    *   The collection is a **Taxonomy Field**, allowing the user to select a category (e.g., from WooCommerce).
    *   The code then uses a standard `WP_Query` to fetch the latest **two** products from the selected category, ensuring the product details (image, title, price) are pulled directly from the product database, fulfilling the requirement that they are "as per actual product detail."

## 3. Code Structure and Cleanliness

*   **PHP**: All dynamic content is properly escaped using `esc_html()` for text and `esc_url()` for links, preventing XSS vulnerabilities. The code is modular, with clear comments indicating which section of the mobile layout is being rendered.
*   **CSS**: The `style.css` uses a **mobile-first** approach, with all base styles optimized for smaller screens. A single media query is included to demonstrate how the layout would adapt for larger screens (e.g., changing the product grid to 4 columns). Class names follow a clean, block-element-modifier (BEM) style convention (e.g., `announcement-bar__text`, `product-card__image`).

## 4. Submission Requirements

The provided files represent the complete code solution. To fulfill the submission requirements:

1.  **GitHub Repository**: The files (`page-homepage.php`, `style.css`, `functions.php`, `acf_structure.md`, and this explanation) should be uploaded to a GitHub repository.
2.  **Screen Recording**: The video demonstration would involve:
    *   **Frontend Demo**: Showing the rendered page (using the provided CSS) on a mobile emulator.
    *   **Admin Panel Demo**: Showing the ACF field group setup and demonstrating how changing the text in the "Announcement Bar" field, uploading a new "Hero Banner Image," or selecting a new "New Arrivals Collection" instantly updates the frontend.
    *   **CMS Structure Explanation**: Briefly walking through the `acf_structure.md` to explain the design choice.

This solution is ready for deployment in a standard WordPress environment with the ACF plugin installed. The `functions.php` file includes mockups to allow for local testing of the template logic without a full database setup.
