# Advanced Custom Fields (ACF) Structure Design

The following ACF Field Groups and fields are designed to meet the assignment's requirement for a dynamic, non-developer-friendly content management system (CMS). The structure is organized to map directly to the mobile homepage sections.

## 1. Field Group: Mobile Homepage Content

**Location Rule:** `Page Template` is equal to `Homepage Template` (A custom page template will be created for the homepage).

| Field Label | Field Name (Slug) | Field Type | Instructions/Notes |
| :--- | :--- | :--- | :--- |
| **Announcement Bar** | `announcement_bar_text` | Text | Enter the text for the black announcement bar at the top of the page. |
| **Hero Banner Image** | `hero_banner_image` | Image | Upload the main image for the hero section. |
| **Hero Banner Heading** | `hero_banner_heading` | Text | Main heading text for the hero banner. |
| **Hero Banner Subheading** | `hero_banner_subheading` | Text | Subheading text for the hero banner. |
| **Hero Banner Button Text** | `hero_banner_button_text` | Text | Text to display on the call-to-action button. |
| **Hero Banner Button Link** | `hero_banner_button_link` | URL | The URL the button should link to. |
| **Brand Logos** | `brand_logos` | Repeater | Add, remove, or reorder brand logos dynamically. |
| **-> Brand Logo Image** | `brand_logo_image` | Image | Sub-field: Upload a single brand logo image. |
| **New Arrivals Heading** | `new_arrivals_heading` | Text | Heading for the New Arrivals section (e.g., "New Arrivals"). |
| **New Arrivals Collection** | `new_arrivals_collection` | Taxonomy | Select the product category or collection to display in this section. (Assumes WooCommerce or similar product system is in use). |

This structure ensures that every required content element is easily editable from the WordPress page editor, fulfilling the core dynamic content requirement.

## 2. Product Card Data (Assumed WooCommerce Integration)

The assignment specifies that product card details (price, image) should be "as per actual product detail." This implies the use of a standard e-commerce plugin like **WooCommerce**.

The code will rely on standard WordPress/WooCommerce functions to retrieve product data based on the category selected in the `new_arrivals_collection` field, ensuring the data is always dynamic and not hardcoded.

---
*Next step: Develop the WordPress Code (PHP/HTML) using this ACF structure.*
