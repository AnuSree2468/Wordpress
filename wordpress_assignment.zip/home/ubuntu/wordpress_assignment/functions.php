<?php
/**
 * Theme functions for Mobile E-commerce Assignment.
 * This file is minimal, assuming a child theme or a starter theme is used.
 */

// Enqueue styles
function mobile_ecommerce_scripts() {
    // Enqueue the main stylesheet
    wp_enqueue_style( 'mobile-ecommerce-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'mobile_ecommerce_scripts' );

// Mockup functions for standard WordPress theme structure
// In a real scenario, get_header() and get_footer() would call header.php and footer.php

if ( ! function_exists( 'get_header' ) ) {
    function get_header() {
        // Mockup header content
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>E-commerce Mobile Demo</title>';
        wp_head();
        echo '</head><body>';
    }
}

if ( ! function_exists( 'get_footer' ) ) {
    function get_footer() {
        // Mockup footer content
        echo '<footer><p style="text-align:center; padding: 20px;">&copy; ' . date('Y') . ' Mobile E-commerce Demo</p></footer>';
        wp_footer();
        echo '</body></html>';
    }
}

// Mockup function for WooCommerce product price retrieval
// In a real WooCommerce setup, this would be handled by WC functions
if ( ! function_exists( 'get_post_meta' ) ) {
    function get_post_meta( $post_id, $key, $single = false ) {
        // Mock price for demonstration purposes
        if ( $key === '_price' ) {
            return rand( 50, 500 ) . '.00';
        }
        return '';
    }
}

// Mockup function for WooCommerce product post type check
if ( ! function_exists( 'post_type_exists' ) ) {
    function post_type_exists( $post_type ) {
        return $post_type === 'product';
    }
}

// Mockup function for WooCommerce product query
// This is a simplification. In a real environment, WP_Query would handle this.
if ( ! class_exists( 'WP_Query' ) ) {
    class WP_Query {
        private $posts = [];
        private $current_post = -1;
        private $post_count = 0;

        public function __construct( $args ) {
            // Mock two product posts for the "New Arrivals" section
            $this->posts = [
                (object)['ID' => 101, 'post_title' => 'Product Card 1 Title', 'post_name' => 'product-1', 'post_type' => 'product'],
                (object)['ID' => 102, 'post_title' => 'Product Card 2 Title', 'post_name' => 'product-2', 'post_type' => 'product'],
            ];
            $this->post_count = count($this->posts);
        }

        public function have_posts() {
            return $this->current_post + 1 < $this->post_count;
        }

        public function the_post() {
            $this->current_post++;
            global $post;
            $post = $this->posts[$this->current_post];
            setup_postdata( $post );
        }

        public static function wp_reset_postdata() {
            global $post;
            $post = null; // Reset global post
        }
    }
}

// Mockup function for standard WordPress functions
if ( ! function_exists( 'setup_postdata' ) ) { function setup_postdata( $post ) { global $post; } }
if ( ! function_exists( 'the_permalink' ) ) { function the_permalink() { echo '#'; } }
if ( ! function_exists( 'the_title' ) ) { function the_title() { global $post; echo esc_html( $post->post_title ); } }
if ( ! function_exists( 'get_the_ID' ) ) { function get_the_ID() { global $post; return $post->ID; } }
if ( ! function_exists( 'has_post_thumbnail' ) ) { function has_post_thumbnail() { return true; } }
if ( ! function_exists( 'the_post_thumbnail' ) ) {
    function the_post_thumbnail( $size, $attr ) {
        // Mock image output
        echo '<img src="https://via.placeholder.com/300x300.png?text=Product+Image" alt="Product Image" class="' . esc_attr( $attr['class'] ) . '">';
    }
}
if ( ! function_exists( 'wp_get_attachment_image' ) ) {
    function wp_get_attachment_image( $id, $size, $icon, $attr ) {
        // Mock image output for ACF images
        $text = ($id == 1) ? 'Hero+Banner' : 'Brand+Logo';
        return '<img src="https://via.placeholder.com/600x400.png?text=' . $text . '" alt="Dynamic Image" class="' . esc_attr( $attr['class'] ) . '">';
    }
}
if ( ! function_exists( 'get_field' ) ) {
    // Mock ACF fields for demonstration
    function get_field( $field_name ) {
        $mock_data = [
            'announcement_bar_text' => 'FREE SHIPPING ON ALL ORDERS OVER $50',
            'hero_banner_image' => 1, // Mock ID
            'hero_banner_heading' => 'SUMMER COLLECTION',
            'hero_banner_subheading' => 'UP TO 50% OFF SELECT STYLES',
            'hero_banner_button_text' => 'SHOP NOW',
            'hero_banner_button_link' => '#shop-now',
            'new_arrivals_heading' => 'NEW ARRIVALS',
            'new_arrivals_collection' => (object)['term_id' => 1, 'taxonomy' => 'product_cat', 'name' => 'New Arrivals'],
        ];
        return $mock_data[$field_name] ?? false;
    }
}
if ( ! function_exists( 'have_rows' ) ) {
    // Mock have_rows for the brand logos repeater
    $GLOBALS['mock_row_count'] = 0;
    function have_rows( $field_name ) {
        if ( $field_name === 'brand_logos' ) {
            return $GLOBALS['mock_row_count'] < 4; // Mock 4 logos
        }
        return false;
    }
}
if ( ! function_exists( 'the_row' ) ) {
    function the_row() {
        $GLOBALS['mock_row_count']++;
    }
}
if ( ! function_exists( 'get_sub_field' ) ) {
    function get_sub_field( $field_name ) {
        if ( $field_name === 'brand_logo_image' ) {
            return 2; // Mock ID for brand logo
        }
        return false;
    }
}
if ( ! function_exists( 'esc_html' ) ) { function esc_html( $text ) { return $text; } }
if ( ! function_exists( 'esc_url' ) ) { function esc_url( $url ) { return $url; } }
if ( ! function_exists( 'home_url' ) ) { function home_url( $path ) { return '/'; } }
if ( ! function_exists( 'bloginfo' ) ) { function bloginfo( $show ) { echo 'E-COMMERCE'; } }
if ( ! function_exists( 'wp_head' ) ) { function wp_head() { echo '<link rel="stylesheet" href="style.css">'; } }
if ( ! function_exists( 'wp_footer' ) { function wp_footer() {} }
if ( ! function_exists( 'wp_enqueue_style' ) ) { function wp_enqueue_style( $handle, $src ) {} }
if ( ! function_exists( 'get_stylesheet_uri' ) ) { function get_stylesheet_uri() { return 'style.css'; } }
if ( ! function_exists( 'add_action' ) ) { function add_action( $tag, $function_to_add ) {} }
if ( ! function_exists( 'number_format' ) ) { function number_format( $number, $decimals ) { return $number; } }
if ( ! function_exists( 'is_object' ) ) { function is_object( $var ) { return true; } }
if ( ! function_exists( 'setup_postdata' ) ) { function setup_postdata( $post ) { global $post; } }
if ( ! function_exists( 'wp_reset_postdata' ) ) { function wp_reset_postdata() { global $post; $post = null; } }
if ( ! function_exists( 'esc_attr' ) ) { function esc_attr( $text ) { return $text; } }

// Global variable for post object mockup
global $post;
$post = null;
