<?php
/**
 * Template Name: Mobile Homepage Template
 * Description: A custom template for the mobile-first homepage, utilizing ACF for dynamic content.
 */

get_header(); // Standard WordPress header

// Check if ACF is active and the fields are available
if ( function_exists( 'get_field' ) ) :
?>

<main id="primary" class="site-main">

    <?php
    // 1. ANNOUNCEMENT BAR
    $announcement_text = get_field('announcement_bar_text');
    if ( $announcement_text ) :
    ?>
    <div class="announcement-bar">
        <p class="announcement-bar__text"><?php echo esc_html( $announcement_text ); ?></p>
    </div>
    <?php endif; ?>

    <?php
    // 2. HEADER + LOGO (Mockup structure, assuming standard header includes site logo/title)
    ?>
    <header class="site-header">
        <div class="site-header__logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                <!-- Replace with dynamic logo if required, or use site title -->
                <h1 class="site-title"><?php bloginfo( 'name' ); ?></h1>
            </a>
        </div>
        <nav class="site-header__nav">
            <!-- Mobile menu icon/search icon here -->
            <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">Menu</button>
        </nav>
    </header>

    <?php
    // 3. HERO BANNER (Image + Text + Button)
    $hero_image_id = get_field('hero_banner_image');
    $hero_heading = get_field('hero_banner_heading');
    $hero_subheading = get_field('hero_banner_subheading');
    $button_text = get_field('hero_banner_button_text');
    $button_link = get_field('hero_banner_button_link');

    if ( $hero_image_id || $hero_heading ) :
    ?>
    <section class="hero-banner">
        <?php if ( $hero_image_id ) : ?>
            <div class="hero-banner__image-wrapper">
                <?php echo wp_get_attachment_image( $hero_image_id, 'full', false, array( 'class' => 'hero-banner__image' ) ); ?>
            </div>
        <?php endif; ?>

        <div class="hero-banner__content">
            <?php if ( $hero_heading ) : ?>
                <h2 class="hero-banner__heading"><?php echo esc_html( $hero_heading ); ?></h2>
            <?php endif; ?>

            <?php if ( $hero_subheading ) : ?>
                <p class="hero-banner__subheading"><?php echo esc_html( $hero_subheading ); ?></p>
            <?php endif; ?>

            <?php if ( $button_text && $button_link ) : ?>
                <a href="<?php echo esc_url( $button_link ); ?>" class="hero-banner__button">
                    <?php echo esc_html( $button_text ); ?>
                </a>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php
    // 4. BRAND LOGOS (Repeater Field)
    if ( have_rows('brand_logos') ) :
    ?>
    <section class="brand-logos-bar">
        <div class="brand-logos-bar__list">
            <?php while ( have_rows('brand_logos') ) : the_row();
                $logo_image_id = get_sub_field('brand_logo_image');
                if ( $logo_image_id ) :
            ?>
                <div class="brand-logos-bar__item">
                    <?php echo wp_get_attachment_image( $logo_image_id, 'medium', false, array( 'class' => 'brand-logos-bar__logo' ) ); ?>
                </div>
            <?php
                endif;
            endwhile;
            ?>
        </div>
    </section>
    <?php endif; ?>

    <?php
    // 5. "NEW ARRIVALS" SECTION
    $new_arrivals_heading = get_field('new_arrivals_heading');
    $collection_term = get_field('new_arrivals_collection'); // ACF Taxonomy field returns a term object or ID

    if ( $new_arrivals_heading || $collection_term ) :
    ?>
    <section class="new-arrivals-section">
        <?php if ( $new_arrivals_heading ) : ?>
            <h2 class="new-arrivals-section__heading"><?php echo esc_html( $new_arrivals_heading ); ?></h2>
        <?php endif; ?>

        <?php
        // Assuming a custom post type 'product' and a taxonomy 'product_cat' (like WooCommerce)
        if ( $collection_term && is_object( $collection_term ) ) :
            $args = array(
                'post_type'      => 'product', // Use 'product' CPT
                'posts_per_page' => 2,         // Only show 2 product cards
                'tax_query'      => array(
                    array(
                        'taxonomy' => $collection_term->taxonomy,
                        'field'    => 'term_id',
                        'terms'    => $collection_term->term_id,
                    ),
                ),
                'orderby'        => 'date',
                'order'          => 'DESC',
            );

            $products_query = new WP_Query( $args );

            if ( $products_query->have_posts() ) :
            ?>
            <div class="new-arrivals-section__products-grid">
                <?php while ( $products_query->have_posts() ) : $products_query->the_post(); ?>
                    <div class="product-card">
                        <a href="<?php the_permalink(); ?>" class="product-card__link">
                            <div class="product-card__image-wrapper">
                                <?php
                                // Product Image
                                if ( has_post_thumbnail() ) {
                                    the_post_thumbnail( 'medium', array( 'class' => 'product-card__image' ) );
                                } else {
                                    // Placeholder for products without an image
                                    echo '<img src="placeholder.jpg" alt="Product Placeholder" class="product-card__image">';
                                }
                                ?>
                            </div>
                            <div class="product-card__details">
                                <h3 class="product-card__title"><?php the_title(); ?></h3>
                                <?php
                                // Assuming product price is stored as post meta (e.g., '_price' for WooCommerce)
                                $price = get_post_meta( get_the_ID(), '_price', true );
                                if ( $price ) :
                                ?>
                                    <p class="product-card__price">$<?php echo number_format( $price, 2 ); ?></p>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>
            <?php
            wp_reset_postdata();
            endif; // End products_query check
        endif; // End collection_term check
        ?>
    </section>
    <?php endif; ?>

</main><!-- #main -->

<?php
else :
    // Fallback if ACF is not active
    echo '<p>Advanced Custom Fields plugin is required for this template to function.</p>';
endif;

get_footer(); // Standard WordPress footer
